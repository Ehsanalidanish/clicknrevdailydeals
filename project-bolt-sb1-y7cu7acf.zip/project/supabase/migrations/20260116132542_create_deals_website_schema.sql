/*
  # Create ClickNRev Daily Deals Website Schema

  ## Overview
  This migration creates the complete database schema for a deals, coupons, and affiliate offers website.

  ## New Tables Created

  ### 1. `categories`
  Stores product categories for organizing deals
  - `id` (uuid, primary key) - Unique category identifier
  - `name` (text) - Category name (e.g., "Electronics Deals")
  - `slug` (text, unique) - URL-friendly slug
  - `description` (text) - Category description
  - `image_url` (text, nullable) - Category image
  - `display_order` (integer) - Sort order for display
  - `created_at` (timestamptz) - Creation timestamp

  ### 2. `brands`
  Stores brand/merchant information
  - `id` (uuid, primary key) - Unique brand identifier
  - `name` (text) - Brand name
  - `slug` (text, unique) - URL-friendly slug
  - `logo_url` (text, nullable) - Brand logo URL
  - `website_url` (text, nullable) - Brand website
  - `featured` (boolean) - Whether brand is featured
  - `created_at` (timestamptz) - Creation timestamp

  ### 3. `deals`
  Main deals/offers table
  - `id` (uuid, primary key) - Unique deal identifier
  - `title` (text) - Deal title
  - `slug` (text, unique) - URL-friendly slug
  - `description` (text) - Original deal description
  - `category_id` (uuid, foreign key) - References categories
  - `brand_id` (uuid, foreign key, nullable) - References brands
  - `deal_type` (text) - Type: 'product', 'service', 'coupon'
  - `original_price` (numeric, nullable) - Original price
  - `discounted_price` (numeric, nullable) - Sale price
  - `discount_percentage` (integer, nullable) - Discount %
  - `coupon_code` (text, nullable) - Promo/coupon code
  - `affiliate_link` (text) - Affiliate tracking URL
  - `image_url` (text, nullable) - Product/offer image
  - `key_benefits` (text[], nullable) - Array of benefits
  - `drawbacks` (text[], nullable) - Array of drawbacks
  - `expires_at` (timestamptz, nullable) - Deal expiration
  - `featured` (boolean) - Featured deal flag
  - `trending` (boolean) - Trending deal flag
  - `is_active` (boolean) - Active status
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ## Security
  - Row Level Security (RLS) enabled on all tables
  - Public read access for all users (read-only website)
  - No insert/update/delete policies (content managed via backend/admin)

  ## Notes
  - All tables use UUID primary keys
  - Timestamps use timestamptz for timezone awareness
  - Slug fields are unique for SEO-friendly URLs
  - Arrays store structured data for benefits/drawbacks
  - Prices stored as numeric for precision
*/

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text NOT NULL,
  image_url text,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create brands table
CREATE TABLE IF NOT EXISTS brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  logo_url text,
  website_url text,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create deals table
CREATE TABLE IF NOT EXISTS deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text NOT NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  brand_id uuid REFERENCES brands(id) ON DELETE SET NULL,
  deal_type text NOT NULL DEFAULT 'product',
  original_price numeric,
  discounted_price numeric,
  discount_percentage integer,
  coupon_code text,
  affiliate_link text NOT NULL,
  image_url text,
  key_benefits text[],
  drawbacks text[],
  expires_at timestamptz,
  featured boolean DEFAULT false,
  trending boolean DEFAULT false,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE deals ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access
CREATE POLICY "Public can view categories"
  ON categories FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can view brands"
  ON brands FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can view active deals"
  ON deals FOR SELECT
  TO anon
  USING (is_active = true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_deals_category ON deals(category_id);
CREATE INDEX IF NOT EXISTS idx_deals_brand ON deals(brand_id);
CREATE INDEX IF NOT EXISTS idx_deals_featured ON deals(featured) WHERE featured = true;
CREATE INDEX IF NOT EXISTS idx_deals_trending ON deals(trending) WHERE trending = true;
CREATE INDEX IF NOT EXISTS idx_deals_expires ON deals(expires_at) WHERE expires_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_categories_display_order ON categories(display_order);
CREATE INDEX IF NOT EXISTS idx_brands_featured ON brands(featured) WHERE featured = true;