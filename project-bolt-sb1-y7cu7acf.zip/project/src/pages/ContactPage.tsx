import { Mail, MessageSquare, Send } from 'lucide-react';

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Mail className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Contact Us</h1>
          <p className="text-xl text-orange-50">We'd love to hear from you</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-xl p-8 shadow-md">
            <div className="bg-orange-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <Mail className="h-6 w-6 text-orange-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Email Us</h3>
            <p className="text-gray-600 mb-4">Get in touch with our team for any inquiries</p>
            <a href="mailto:hello@clicknrevdailydeals.com" className="text-orange-600 hover:text-orange-700 font-semibold">
              hello@clicknrevdailydeals.com
            </a>
          </div>

          <div className="bg-white rounded-xl p-8 shadow-md">
            <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <MessageSquare className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Send a Message</h3>
            <p className="text-gray-600 mb-4">Fill out the form below and we'll respond promptly</p>
            <a href="#contact-form" className="text-blue-600 hover:text-blue-700 font-semibold">
              Go to form
            </a>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8 md:p-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-2 text-center">Send Us a Message</h2>
          <p className="text-gray-600 text-center mb-8">
            Have a question, suggestion, or feedback? We're here to help!
          </p>

          <form id="contact-form" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-600 focus:border-transparent"
                  placeholder="John Doe"
                  required
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-600 focus:border-transparent"
                  placeholder="john@example.com"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="subject" className="block text-sm font-semibold text-gray-700 mb-2">
                Subject
              </label>
              <select
                id="subject"
                name="subject"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-600 focus:border-transparent"
                required
              >
                <option value="">Select a subject</option>
                <option value="general">General Inquiry</option>
                <option value="deal">Report a Deal Issue</option>
                <option value="partnership">Partnership Opportunity</option>
                <option value="technical">Technical Support</option>
                <option value="feedback">Feedback or Suggestion</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-600 focus:border-transparent resize-none"
                placeholder="Tell us how we can help you..."
                required
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full bg-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-orange-700 transition shadow-md flex items-center justify-center"
            >
              <Send className="mr-2 h-5 w-5" />
              Send Message
            </button>
          </form>
        </div>

        <div className="mt-12 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-bold text-gray-900 mb-2">How quickly will I receive a response?</h4>
              <p className="text-gray-700">
                We typically respond to all inquiries within 24-48 hours during business days. For urgent matters, please indicate so in your message subject.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-2">Can I submit deals to be featured?</h4>
              <p className="text-gray-700">
                Yes! We welcome deal submissions. Please use the contact form above with the subject "Deal Submission" and include all relevant details about the offer.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-2">Do you offer partnership opportunities?</h4>
              <p className="text-gray-700">
                We're always open to exploring partnerships with brands and retailers. Please select "Partnership Opportunity" in the subject field and tell us about your business.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-2">How do I report an expired or incorrect deal?</h4>
              <p className="text-gray-700">
                Select "Report a Deal Issue" in the subject field and provide the deal link or name along with details about the issue. We'll investigate and update our listings promptly.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">
            For specific inquiries, you can also reach us at:
          </p>
          <div className="space-y-2 text-gray-700">
            <p><strong>Partnerships:</strong> partners@clicknrevdailydeals.com</p>
            <p><strong>Technical Support:</strong> support@clicknrevdailydeals.com</p>
            <p><strong>Privacy Concerns:</strong> privacy@clicknrevdailydeals.com</p>
          </div>
        </div>
      </div>
    </div>
  );
}
