import { useEffect, useState } from 'react';
import { Tag, ExternalLink, Copy, Check, AlertCircle, TrendingUp, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Deal = Database['public']['Tables']['deals']['Row'];

interface DealPageProps {
  slug: string;
}

export default function DealPage({ slug }: DealPageProps) {
  const [deal, setDeal] = useState<Deal | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    loadDeal();
  }, [slug]);

  const loadDeal = async () => {
    setLoading(true);

    const { data } = await supabase
      .from('deals')
      .select('*')
      .eq('slug', slug)
      .eq('is_active', true)
      .maybeSingle();

    if (data) {
      setDeal(data);
    }

    setLoading(false);
  };

  const formatPrice = (price: number | null) => {
    if (!price) return null;
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(price);
  };

  const copyCode = () => {
    if (deal?.coupon_code) {
      navigator.clipboard.writeText(deal.coupon_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return null;
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading deal...</p>
        </div>
      </div>
    );
  }

  if (!deal) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Tag className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Deal Not Found</h2>
          <p className="text-gray-600 mb-6">The deal you're looking for doesn't exist or has expired.</p>
          <a href="#" className="bg-orange-600 text-white px-6 py-3 rounded-full font-semibold hover:bg-orange-700 transition">
            Back to Home
          </a>
        </div>
      </div>
    );
  }

  const isExpiring = deal.expires_at && new Date(deal.expires_at) < new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="relative h-96 lg:h-auto bg-gray-200">
              {deal.image_url ? (
                <img src={deal.image_url} alt={deal.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Tag className="h-24 w-24 text-gray-400" />
                </div>
              )}
              {deal.discount_percentage && (
                <div className="absolute top-6 right-6 bg-red-600 text-white px-4 py-2 rounded-full font-bold text-lg shadow-lg">
                  {deal.discount_percentage}% OFF
                </div>
              )}
              {deal.trending && (
                <div className="absolute top-6 left-6 bg-orange-600 text-white px-3 py-1 rounded-full font-semibold text-sm flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  Trending
                </div>
              )}
            </div>

            <div className="p-8">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">
                {deal.title}
              </h1>

              <div className="mb-6">
                {deal.original_price && deal.discounted_price ? (
                  <div className="flex items-baseline space-x-3">
                    <span className="text-4xl font-bold text-orange-600">{formatPrice(deal.discounted_price)}</span>
                    <span className="text-2xl text-gray-400 line-through">{formatPrice(deal.original_price)}</span>
                  </div>
                ) : null}
              </div>

              {deal.coupon_code && (
                <div className="bg-orange-50 border-2 border-dashed border-orange-600 rounded-xl p-4 mb-6">
                  <p className="text-sm text-gray-700 font-semibold mb-2">PROMO CODE</p>
                  <div className="flex items-center justify-between">
                    <code className="text-2xl font-bold text-orange-600">{deal.coupon_code}</code>
                    <button
                      onClick={copyCode}
                      className="flex items-center bg-orange-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-orange-700 transition"
                    >
                      {copied ? (
                        <>
                          <Check className="h-4 w-4 mr-2" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4 mr-2" />
                          Copy Code
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {deal.expires_at && (
                <div className={`flex items-center space-x-2 mb-6 ${isExpiring ? 'text-red-600' : 'text-gray-600'}`}>
                  <Clock className="h-5 w-5" />
                  <span className="font-medium">
                    {isExpiring ? 'Expires soon: ' : 'Valid until: '}
                    {formatDate(deal.expires_at)}
                  </span>
                </div>
              )}

              <a
                href={deal.affiliate_link}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-orange-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-orange-700 transition shadow-lg flex items-center justify-center mb-6"
              >
                Get This Deal
                <ExternalLink className="ml-2 h-5 w-5" />
              </a>

              <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-6">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-700 leading-relaxed">
                    <strong>Affiliate Disclosure:</strong> clicknrevdailydeals.com may earn a commission from qualifying purchases made through affiliate links. This comes at no extra cost to you and helps us keep the site running.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-200 p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">About This Deal</h2>
            <p className="text-gray-700 leading-relaxed mb-6">{deal.description}</p>

            {deal.key_benefits && deal.key_benefits.length > 0 && (
              <div className="mb-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">Key Benefits</h3>
                <ul className="space-y-2">
                  {deal.key_benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start">
                      <Check className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {deal.drawbacks && deal.drawbacks.length > 0 && (
              <div className="mb-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">Things to Consider</h3>
                <ul className="space-y-2">
                  {deal.drawbacks.map((drawback, index) => (
                    <li key={index} className="flex items-start">
                      <AlertCircle className="h-5 w-5 text-orange-600 mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{drawback}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-sm text-gray-700">
                <strong>Important Notice:</strong> Prices and availability are subject to change. Please verify the final price on the merchant's website before making a purchase.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
