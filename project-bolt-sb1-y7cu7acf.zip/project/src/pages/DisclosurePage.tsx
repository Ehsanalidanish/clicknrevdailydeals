import { AlertCircle, DollarSign, FileText } from 'lucide-react';

export default function DisclosurePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <FileText className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Affiliate Disclosure</h1>
          <p className="text-xl text-orange-50">Transparency is our priority</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-orange-50 border-l-4 border-orange-600 p-6 mb-8 rounded flex items-start">
          <AlertCircle className="h-6 w-6 text-orange-600 mr-4 mt-1 flex-shrink-0" />
          <div>
            <h2 className="text-lg font-bold text-gray-900 mb-2">Important Notice</h2>
            <p className="text-gray-700 leading-relaxed">
              <strong>ClickNRevDailyDeals.com may earn commissions from qualifying purchases made through affiliate links.</strong> This disclosure explains our affiliate relationships and how we earn revenue.
            </p>
          </div>
        </div>

        <div className="prose prose-lg max-w-none space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">What Are Affiliate Links?</h2>
            <p className="text-gray-700 leading-relaxed">
              Affiliate links are special tracking links that allow us to earn a commission when you click on them and make a purchase from a merchant. These links contain unique identifiers that track the referral from our website to the merchant's website.
            </p>
            <p className="text-gray-700 leading-relaxed">
              When you click on a deal, coupon, or product link on ClickNRevDailyDeals.com and complete a purchase, the merchant may pay us a small percentage of the sale as a commission. This is how we keep our website running and continue providing free deal-finding services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Affiliate Partnerships</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              We participate in various affiliate marketing programs, including but not limited to:
            </p>

            <div className="space-y-4">
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-xl font-bold text-gray-900 mb-2">Amazon Associates</h3>
                <p className="text-gray-700">
                  ClickNRevDailyDeals.com is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com and affiliated international Amazon sites.
                </p>
              </div>

              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-xl font-bold text-gray-900 mb-2">Other Affiliate Networks</h3>
                <p className="text-gray-700 mb-3">We also partner with several other reputable affiliate networks and programs:</p>
                <ul className="list-disc pl-6 text-gray-700 space-y-1">
                  <li>ClickBank</li>
                  <li>CJ Affiliate (Commission Junction)</li>
                  <li>ShareASale</li>
                  <li>Impact</li>
                  <li>Rakuten Advertising</li>
                  <li>Direct brand affiliate programs</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">How This Affects You</h2>

            <div className="bg-green-50 border-l-4 border-green-600 p-6 mb-4 rounded">
              <div className="flex items-start">
                <DollarSign className="h-6 w-6 text-green-600 mr-3 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">No Extra Cost to You</h3>
                  <p className="text-gray-700 leading-relaxed">
                    Using our affiliate links does not cost you anything extra. The price you pay is exactly the same as if you went directly to the merchant's website. The commission we earn comes from the merchant's marketing budget, not from your pocket.
                  </p>
                </div>
              </div>
            </div>

            <p className="text-gray-700 leading-relaxed">
              In fact, using our links may actually save you money because we negotiate exclusive deals and coupon codes that may not be available elsewhere. Our affiliate relationships allow us to provide you with verified deals and special offers.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Editorial Independence</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              While we earn commissions through affiliate links, this does not influence our editorial decisions or the deals we choose to feature. Our commitment is to you, the consumer.
            </p>

            <div className="bg-white rounded-lg p-6 shadow-md space-y-3">
              <div className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">1</span>
                <p className="text-gray-700">We feature deals based on value to consumers, not commission rates.</p>
              </div>
              <div className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">2</span>
                <p className="text-gray-700">We provide honest assessments of products and services, including drawbacks.</p>
              </div>
              <div className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">3</span>
                <p className="text-gray-700">We verify deals and coupons before publishing them.</p>
              </div>
              <div className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">4</span>
                <p className="text-gray-700">We never recommend products or services we wouldn't use ourselves.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Price and Availability Disclaimer</h2>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <p className="text-gray-700 leading-relaxed mb-3">
                <strong>Important:</strong> Prices, availability, and offers are subject to change without notice. While we strive to keep information accurate and up-to-date, merchants may modify their offers at any time.
              </p>
              <p className="text-gray-700 leading-relaxed">
                We recommend verifying the current price, availability, and terms on the merchant's website before making a purchase. We are not responsible for any discrepancies between the information on our site and what is displayed on the merchant's site.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Product Reviews and Recommendations</h2>
            <p className="text-gray-700 leading-relaxed">
              Any product reviews, comparisons, or recommendations on our website represent our honest opinions and assessments. We base our recommendations on factors such as:
            </p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2 mt-3">
              <li>Value for money</li>
              <li>Product quality and features</li>
              <li>Customer reviews and ratings</li>
              <li>Brand reputation</li>
              <li>Deal authenticity and savings potential</li>
            </ul>
            <p className="text-gray-700 leading-relaxed mt-4">
              We encourage you to do your own research and read multiple sources before making purchasing decisions.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Support Helps Us</h2>
            <p className="text-gray-700 leading-relaxed">
              When you use our affiliate links to make purchases, you're supporting our work at no extra cost to yourself. The commissions we earn help us:
            </p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2 mt-3">
              <li>Maintain and improve our website</li>
              <li>Research and verify new deals daily</li>
              <li>Negotiate exclusive coupon codes</li>
              <li>Provide free deal-finding services</li>
              <li>Create helpful content and guides</li>
            </ul>
            <p className="text-gray-700 leading-relaxed mt-4">
              We genuinely appreciate your support and trust in ClickNRevDailyDeals.com.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">FTC Compliance</h2>
            <p className="text-gray-700 leading-relaxed">
              This disclosure is made in accordance with the Federal Trade Commission's 16 CFR Part 255: "Guides Concerning the Use of Endorsements and Testimonials in Advertising." We are committed to full transparency and compliance with all applicable regulations.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Questions About Our Affiliate Relationships?</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              If you have any questions about our affiliate disclosure, how we earn revenue, or our editorial policies, please don't hesitate to contact us.
            </p>
            <div className="bg-gray-100 rounded-lg p-6">
              <p className="text-gray-700">
                <strong>Email:</strong> disclosure@clicknrevdailydeals.com<br />
                <strong>Website:</strong> <a href="#contact" className="text-orange-600 hover:text-orange-700">Contact Form</a>
              </p>
            </div>
          </section>

          <section>
            <div className="bg-white border-2 border-orange-600 rounded-lg p-6 text-center">
              <h3 className="text-xl font-bold text-gray-900 mb-3">Thank You for Your Trust</h3>
              <p className="text-gray-700 leading-relaxed">
                We are committed to maintaining your trust through transparency, honesty, and by always putting your interests first. Thank you for choosing ClickNRevDailyDeals.com as your source for savings.
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
