import { useEffect, useState } from 'react';
import { Tag, Filter } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Deal = Database['public']['Tables']['deals']['Row'];
type Category = Database['public']['Tables']['categories']['Row'];

interface CategoryPageProps {
  slug: string;
}

export default function CategoryPage({ slug }: CategoryPageProps) {
  const [category, setCategory] = useState<Category | null>(null);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCategoryData();
  }, [slug]);

  const loadCategoryData = async () => {
    setLoading(true);

    const categoryRes = await supabase
      .from('categories')
      .select('*')
      .eq('slug', slug)
      .maybeSingle();

    if (categoryRes.data) {
      setCategory(categoryRes.data);

      const dealsRes = await supabase
        .from('deals')
        .select('*')
        .eq('category_id', categoryRes.data.id)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (dealsRes.data) {
        setDeals(dealsRes.data);
      }
    }

    setLoading(false);
  };

  const formatPrice = (price: number | null) => {
    if (!price) return null;
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading deals...</p>
        </div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Tag className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Category Not Found</h2>
          <p className="text-gray-600 mb-6">The category you're looking for doesn't exist.</p>
          <a href="#" className="bg-orange-600 text-white px-6 py-3 rounded-full font-semibold hover:bg-orange-700 transition">
            Back to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-4">
            <Tag className="h-8 w-8 mr-3" />
            <h1 className="text-4xl md:text-5xl font-bold">{category.name}</h1>
          </div>
          <p className="text-xl text-orange-50 max-w-3xl">
            {category.description}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-8">
          <p className="text-gray-600">
            <span className="font-semibold text-gray-900">{deals.length}</span> deals available
          </p>
          <button className="flex items-center text-gray-700 hover:text-orange-600 font-medium">
            <Filter className="h-5 w-5 mr-2" />
            Filter
          </button>
        </div>

        {deals.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {deals.map((deal) => (
              <a
                key={deal.id}
                href={`#deal/${deal.slug}`}
                className="bg-white rounded-xl shadow-md hover:shadow-xl transition overflow-hidden group"
              >
                <div className="relative h-48 bg-gray-200 overflow-hidden">
                  {deal.image_url ? (
                    <img src={deal.image_url} alt={deal.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Tag className="h-16 w-16 text-gray-400" />
                    </div>
                  )}
                  {deal.discount_percentage && (
                    <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full font-bold text-sm">
                      {deal.discount_percentage}% OFF
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-orange-600 transition">
                    {deal.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{deal.description}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      {deal.original_price && deal.discounted_price ? (
                        <div>
                          <span className="text-gray-400 line-through text-sm mr-2">{formatPrice(deal.original_price)}</span>
                          <span className="text-orange-600 font-bold text-xl">{formatPrice(deal.discounted_price)}</span>
                        </div>
                      ) : (
                        <span className="text-orange-600 font-bold text-lg">View Offer</span>
                      )}
                    </div>
                    <button className="bg-orange-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-orange-700 transition text-sm">
                      Get Deal
                    </button>
                  </div>
                </div>
              </a>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Tag className="h-20 w-20 text-gray-300 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-2">No Deals Yet</h3>
            <p className="text-gray-600 mb-6">We're working on adding great deals to this category.</p>
            <a href="#" className="text-orange-600 font-semibold hover:text-orange-700">
              Browse Other Categories
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
