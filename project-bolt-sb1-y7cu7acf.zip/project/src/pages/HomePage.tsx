import { useEffect, useState } from 'react';
import { Tag, TrendingUp, Percent, ShoppingBag, Zap, ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Deal = Database['public']['Tables']['deals']['Row'];
type Category = Database['public']['Tables']['categories']['Row'];
type Brand = Database['public']['Tables']['brands']['Row'];

export default function HomePage() {
  const [featuredDeals, setFeaturedDeals] = useState<Deal[]>([]);
  const [trendingDeals, setTrendingDeals] = useState<Deal[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [dealsRes, trendingRes, categoriesRes, brandsRes] = await Promise.all([
      supabase.from('deals').select('*').eq('featured', true).eq('is_active', true).limit(6),
      supabase.from('deals').select('*').eq('trending', true).eq('is_active', true).limit(4),
      supabase.from('categories').select('*').order('display_order'),
      supabase.from('brands').select('*').eq('featured', true).limit(8),
    ]);

    if (dealsRes.data) setFeaturedDeals(dealsRes.data);
    if (trendingRes.data) setTrendingDeals(trendingRes.data);
    if (categoriesRes.data) setCategories(categoriesRes.data);
    if (brandsRes.data) setBrands(brandsRes.data);
  };

  const formatPrice = (price: number | null) => {
    if (!price) return null;
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-orange-600 via-orange-500 to-red-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Discover Amazing Deals
              <br />
              <span className="text-orange-100">Save Money Every Day</span>
            </h1>
            <p className="text-xl md:text-2xl text-orange-50 mb-8 max-w-3xl mx-auto leading-relaxed">
              Your trusted destination for the best coupons, discounts, and product offers from top brands worldwide
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a
                href="#deals"
                className="bg-white text-orange-600 px-8 py-4 rounded-full font-bold text-lg hover:bg-orange-50 transition shadow-lg inline-flex items-center justify-center"
              >
                <ShoppingBag className="mr-2 h-5 w-5" />
                Browse All Deals
              </a>
              <a
                href="#categories"
                className="border-2 border-white text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:text-orange-600 transition inline-flex items-center justify-center"
              >
                <Tag className="mr-2 h-5 w-5" />
                Shop by Category
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Tag className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Verified Deals</h3>
              <p className="text-gray-600">Every deal is checked and verified to ensure you get real savings</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Percent className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Best Prices</h3>
              <p className="text-gray-600">We compare prices to bring you the most competitive offers</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Daily Updates</h3>
              <p className="text-gray-600">New deals added every day from thousands of trusted retailers</p>
            </div>
          </div>
        </div>
      </section>

      <section id="deals" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Top Daily Deals</h2>
              <p className="text-gray-600">Hand-picked offers you don't want to miss</p>
            </div>
            <a href="#all-deals" className="hidden md:flex items-center text-orange-600 font-semibold hover:text-orange-700">
              View All <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredDeals.map((deal) => (
              <a
                key={deal.id}
                href={`#deal/${deal.slug}`}
                className="bg-white rounded-xl shadow-md hover:shadow-xl transition overflow-hidden group"
              >
                <div className="relative h-48 bg-gray-200 overflow-hidden">
                  {deal.image_url ? (
                    <img src={deal.image_url} alt={deal.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Tag className="h-16 w-16 text-gray-400" />
                    </div>
                  )}
                  {deal.discount_percentage && (
                    <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full font-bold text-sm">
                      {deal.discount_percentage}% OFF
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-orange-600 transition">
                    {deal.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{deal.description}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      {deal.original_price && deal.discounted_price ? (
                        <div>
                          <span className="text-gray-400 line-through text-sm mr-2">{formatPrice(deal.original_price)}</span>
                          <span className="text-orange-600 font-bold text-xl">{formatPrice(deal.discounted_price)}</span>
                        </div>
                      ) : (
                        <span className="text-orange-600 font-bold text-lg">View Offer</span>
                      )}
                    </div>
                    <button className="bg-orange-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-orange-700 transition text-sm">
                      Get Deal
                    </button>
                  </div>
                </div>
              </a>
            ))}
          </div>

          {featuredDeals.length === 0 && (
            <div className="text-center py-12">
              <Tag className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No deals available yet. Check back soon!</p>
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-8">
            <TrendingUp className="h-8 w-8 text-orange-600 mr-3" />
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Trending Now</h2>
              <p className="text-gray-600">Most popular deals this week</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {trendingDeals.map((deal) => (
              <a
                key={deal.id}
                href={`#deal/${deal.slug}`}
                className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl p-6 hover:shadow-lg transition flex items-start space-x-4 group"
              >
                <div className="flex-shrink-0 w-24 h-24 bg-white rounded-lg overflow-hidden">
                  {deal.image_url ? (
                    <img src={deal.image_url} alt={deal.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Tag className="h-8 w-8 text-gray-400" />
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-orange-600 transition">
                    {deal.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-2 line-clamp-2">{deal.description}</p>
                  {deal.coupon_code && (
                    <div className="inline-block bg-white border-2 border-dashed border-orange-600 px-3 py-1 rounded text-orange-600 font-bold text-sm">
                      Code: {deal.coupon_code}
                    </div>
                  )}
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      <section id="categories" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Shop by Category</h2>
            <p className="text-gray-600 text-lg">Find deals in your favorite categories</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories.map((category) => (
              <a
                key={category.id}
                href={`#category/${category.slug}`}
                className="bg-white rounded-xl p-6 text-center hover:shadow-lg transition group"
              >
                <div className="bg-gradient-to-br from-orange-100 to-orange-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition">
                  <Tag className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="font-semibold text-gray-900 group-hover:text-orange-600 transition">{category.name}</h3>
              </a>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Featured Brands</h2>
            <p className="text-gray-600 text-lg">Top retailers offering exclusive deals</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {brands.map((brand) => (
              <div
                key={brand.id}
                className="bg-gray-50 rounded-xl p-6 flex items-center justify-center hover:shadow-md transition h-24"
              >
                {brand.logo_url ? (
                  <img src={brand.logo_url} alt={brand.name} className="max-h-12 max-w-full object-contain" />
                ) : (
                  <span className="text-gray-700 font-semibold text-lg">{brand.name}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Never Miss a Deal</h2>
          <p className="text-xl text-orange-50 mb-8">
            Check back daily for new offers or browse our categories to find exactly what you need
          </p>
          <a
            href="#deals"
            className="bg-white text-orange-600 px-8 py-4 rounded-full font-bold text-lg hover:bg-orange-50 transition shadow-lg inline-block"
          >
            Explore All Deals
          </a>
        </div>
      </section>
    </div>
  );
}
