import { Tag, Target, Heart, Users, Shield } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Tag className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About ClickNRevDailyDeals</h1>
          <p className="text-xl text-orange-50">Your trusted partner in smart shopping and incredible savings</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Who We Are</h2>
          <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed space-y-4">
            <p>
              ClickNRevDailyDeals.com is a dedicated deals and coupons platform that helps everyday shoppers discover amazing discounts, promotional codes, and product offers from thousands of trusted brands and retailers worldwide.
            </p>
            <p>
              Founded with a simple mission to make quality products more accessible and affordable, we curate and verify deals across multiple categories including electronics, fashion, home goods, fitness, baby products, and much more.
            </p>
            <p>
              Our team works tirelessly to bring you the most current and valuable offers from reputable affiliate programs including Amazon Associates, ClickBank, CJ Affiliate, ShareASale, Impact, and direct brand partnerships.
            </p>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
          <div className="bg-white rounded-xl p-8 shadow-md border-l-4 border-orange-600">
            <p className="text-xl text-gray-700 leading-relaxed">
              <strong className="text-orange-600">To empower consumers to save money</strong> by providing transparent, verified, and up-to-date information about the best deals available online, while maintaining the highest standards of integrity and trust.
            </p>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">What Makes Us Different</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <div className="bg-orange-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Verified Deals</h3>
              <p className="text-gray-600">
                Every deal and coupon is manually checked and verified before being published to ensure you get legitimate savings.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-md">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Heart className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Consumer First</h3>
              <p className="text-gray-600">
                We prioritize your interests above all else, providing honest reviews and transparent information about every offer.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-md">
              <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Target className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Curated Selection</h3>
              <p className="text-gray-600">
                We don't just list every deal we find. Our team curates offers that provide genuine value and savings.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-md">
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Community Focused</h3>
              <p className="text-gray-600">
                We build our platform around what matters to you, constantly updating and improving based on shopper needs.
              </p>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">How We Work</h2>
          <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed space-y-4">
            <p>
              ClickNRevDailyDeals.com operates as an affiliate marketing platform. This means when you click on a deal or use a coupon code we provide and make a purchase, we may earn a small commission from the merchant. This commission comes at absolutely no extra cost to you.
            </p>
            <p>
              These commissions help us maintain and improve our website, allowing us to continue providing free deal-finding services to shoppers like you. We are committed to full transparency about our affiliate relationships and always disclose when links are affiliate links.
            </p>
            <p>
              Our editorial integrity is never compromised. We feature deals based on value to consumers, not commission rates. If a deal isn't worth sharing, we won't share it regardless of potential earnings.
            </p>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Values</h2>
          <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-8">
            <ul className="space-y-4">
              <li className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">1</span>
                <div>
                  <strong className="text-gray-900">Transparency:</strong>
                  <span className="text-gray-700"> We clearly disclose all affiliate relationships and never hide our business model.</span>
                </div>
              </li>
              <li className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">2</span>
                <div>
                  <strong className="text-gray-900">Honesty:</strong>
                  <span className="text-gray-700"> We provide accurate information and never make misleading claims about savings or products.</span>
                </div>
              </li>
              <li className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">3</span>
                <div>
                  <strong className="text-gray-900">Quality:</strong>
                  <span className="text-gray-700"> We curate only deals that offer genuine value and come from reputable merchants.</span>
                </div>
              </li>
              <li className="flex items-start">
                <span className="bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0 font-bold text-sm">4</span>
                <div>
                  <strong className="text-gray-900">Respect:</strong>
                  <span className="text-gray-700"> We respect your time, intelligence, and trust by providing a straightforward shopping experience.</span>
                </div>
              </li>
            </ul>
          </div>
        </section>

        <section>
          <div className="bg-white rounded-xl p-8 shadow-md text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Questions or Feedback?</h2>
            <p className="text-gray-600 mb-6">
              We'd love to hear from you. Whether you have a question, suggestion, or just want to say hello, we're here to help.
            </p>
            <a
              href="#contact"
              className="inline-block bg-orange-600 text-white px-8 py-3 rounded-full font-bold hover:bg-orange-700 transition"
            >
              Contact Us
            </a>
          </div>
        </section>
      </div>
    </div>
  );
}
