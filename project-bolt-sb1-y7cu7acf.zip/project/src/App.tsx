import { useEffect, useState } from 'react';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import CategoryPage from './pages/CategoryPage';
import DealPage from './pages/DealPage';
import AboutPage from './pages/AboutPage';
import PrivacyPage from './pages/PrivacyPage';
import DisclosurePage from './pages/DisclosurePage';
import ContactPage from './pages/ContactPage';

type Route = {
  type: 'home' | 'category' | 'deal' | 'about' | 'privacy' | 'disclosure' | 'contact';
  slug?: string;
};

function App() {
  const [route, setRoute] = useState<Route>({ type: 'home' });

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);

      if (!hash) {
        setRoute({ type: 'home' });
      } else if (hash.startsWith('category/')) {
        setRoute({ type: 'category', slug: hash.replace('category/', '') });
      } else if (hash.startsWith('deal/')) {
        setRoute({ type: 'deal', slug: hash.replace('deal/', '') });
      } else if (hash === 'about') {
        setRoute({ type: 'about' });
      } else if (hash === 'privacy') {
        setRoute({ type: 'privacy' });
      } else if (hash === 'disclosure') {
        setRoute({ type: 'disclosure' });
      } else if (hash === 'contact') {
        setRoute({ type: 'contact' });
      } else if (hash === 'deals' || hash === 'all-deals') {
        setRoute({ type: 'home' });
        setTimeout(() => {
          const dealsSection = document.getElementById('deals');
          if (dealsSection) {
            dealsSection.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      } else if (hash === 'categories') {
        setRoute({ type: 'home' });
        setTimeout(() => {
          const categoriesSection = document.getElementById('categories');
          if (categoriesSection) {
            categoriesSection.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      } else {
        setRoute({ type: 'home' });
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderPage = () => {
    switch (route.type) {
      case 'category':
        return route.slug ? <CategoryPage slug={route.slug} /> : <HomePage />;
      case 'deal':
        return route.slug ? <DealPage slug={route.slug} /> : <HomePage />;
      case 'about':
        return <AboutPage />;
      case 'privacy':
        return <PrivacyPage />;
      case 'disclosure':
        return <DisclosurePage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navigation />
      <main className="flex-grow">
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
}

export default App;
