import { Tag, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const categories = [
    { name: 'Electronics', slug: 'electronics' },
    { name: 'Home & Kitchen', slug: 'home-kitchen' },
    { name: 'Fashion & Accessories', slug: 'fashion' },
    { name: 'Fitness & Wellness', slug: 'fitness' },
    { name: 'Baby & Kids', slug: 'baby-kids' },
  ];

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <a href="#" className="flex items-center space-x-2">
              <Tag className="h-8 w-8 text-orange-600" />
              <span className="text-xl font-bold text-gray-900">ClickNRev<span className="text-orange-600">DailyDeals</span></span>
            </a>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-orange-600 font-medium transition">Home</a>
            <div className="relative group">
              <button className="text-gray-700 hover:text-orange-600 font-medium transition">
                Categories
              </button>
              <div className="absolute left-0 mt-2 w-56 bg-white shadow-lg rounded-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                {categories.map((cat) => (
                  <a
                    key={cat.slug}
                    href={`#category/${cat.slug}`}
                    className="block px-4 py-3 text-gray-700 hover:bg-orange-50 hover:text-orange-600 transition"
                  >
                    {cat.name}
                  </a>
                ))}
              </div>
            </div>
            <a href="#about" className="text-gray-700 hover:text-orange-600 font-medium transition">About</a>
            <a href="#contact" className="text-gray-700 hover:text-orange-600 font-medium transition">Contact</a>
            <a
              href="#deals"
              className="bg-orange-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-orange-700 transition shadow-md"
            >
              View All Deals
            </a>
          </div>

          <button
            className="md:hidden text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-4 py-4 space-y-3">
            <a href="#" className="block text-gray-700 hover:text-orange-600 font-medium">Home</a>
            <div className="space-y-2">
              <p className="text-gray-900 font-semibold">Categories</p>
              {categories.map((cat) => (
                <a
                  key={cat.slug}
                  href={`#category/${cat.slug}`}
                  className="block pl-4 text-gray-600 hover:text-orange-600"
                >
                  {cat.name}
                </a>
              ))}
            </div>
            <a href="#about" className="block text-gray-700 hover:text-orange-600 font-medium">About</a>
            <a href="#contact" className="block text-gray-700 hover:text-orange-600 font-medium">Contact</a>
            <a
              href="#deals"
              className="block text-center bg-orange-600 text-white px-6 py-2 rounded-full font-semibold"
            >
              View All Deals
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
