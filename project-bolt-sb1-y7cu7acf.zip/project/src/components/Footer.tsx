import { Tag, Mail, Facebook, Twitter, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Tag className="h-8 w-8 text-orange-600" />
              <span className="text-xl font-bold text-white">ClickNRev<span className="text-orange-600">DailyDeals</span></span>
            </div>
            <p className="text-gray-400 mb-4 leading-relaxed">
              Your trusted source for the best deals, coupons, and product offers from top brands and retailers. Save money on electronics, fashion, home goods, and more.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-orange-600 transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-600 transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-600 transition">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-orange-600 transition">Home</a></li>
              <li><a href="#deals" className="hover:text-orange-600 transition">All Deals</a></li>
              <li><a href="#category/electronics" className="hover:text-orange-600 transition">Electronics</a></li>
              <li><a href="#category/fashion" className="hover:text-orange-600 transition">Fashion</a></li>
              <li><a href="#about" className="hover:text-orange-600 transition">About Us</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><a href="#privacy" className="hover:text-orange-600 transition">Privacy Policy</a></li>
              <li><a href="#disclosure" className="hover:text-orange-600 transition">Affiliate Disclosure</a></li>
              <li><a href="#contact" className="hover:text-orange-600 transition">Contact Us</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} ClickNRevDailyDeals.com. All rights reserved.
          </p>
          <p className="text-gray-500 text-xs mt-2">
            This website contains affiliate links. We may earn a commission from qualifying purchases.
          </p>
        </div>
      </div>
    </footer>
  );
}
