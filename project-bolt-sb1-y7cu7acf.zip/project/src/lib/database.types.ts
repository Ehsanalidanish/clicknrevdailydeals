export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      categories: {
        Row: {
          id: string
          name: string
          slug: string
          description: string
          image_url: string | null
          display_order: number
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          slug: string
          description: string
          image_url?: string | null
          display_order?: number
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          description?: string
          image_url?: string | null
          display_order?: number
          created_at?: string
        }
      }
      brands: {
        Row: {
          id: string
          name: string
          slug: string
          logo_url: string | null
          website_url: string | null
          featured: boolean
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          slug: string
          logo_url?: string | null
          website_url?: string | null
          featured?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          logo_url?: string | null
          website_url?: string | null
          featured?: boolean
          created_at?: string
        }
      }
      deals: {
        Row: {
          id: string
          title: string
          slug: string
          description: string
          category_id: string | null
          brand_id: string | null
          deal_type: string
          original_price: number | null
          discounted_price: number | null
          discount_percentage: number | null
          coupon_code: string | null
          affiliate_link: string
          image_url: string | null
          key_benefits: string[] | null
          drawbacks: string[] | null
          expires_at: string | null
          featured: boolean
          trending: boolean
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          slug: string
          description: string
          category_id?: string | null
          brand_id?: string | null
          deal_type?: string
          original_price?: number | null
          discounted_price?: number | null
          discount_percentage?: number | null
          coupon_code?: string | null
          affiliate_link: string
          image_url?: string | null
          key_benefits?: string[] | null
          drawbacks?: string[] | null
          expires_at?: string | null
          featured?: boolean
          trending?: boolean
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          slug?: string
          description?: string
          category_id?: string | null
          brand_id?: string | null
          deal_type?: string
          original_price?: number | null
          discounted_price?: number | null
          discount_percentage?: number | null
          coupon_code?: string | null
          affiliate_link?: string
          image_url?: string | null
          key_benefits?: string[] | null
          drawbacks?: string[] | null
          expires_at?: string | null
          featured?: boolean
          trending?: boolean
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
